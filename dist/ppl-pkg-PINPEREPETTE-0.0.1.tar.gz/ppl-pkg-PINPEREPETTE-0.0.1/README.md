#PPL Python Process Launch


Have you ever had to kill a subprocess or a process launched by a script as a daemon?
with ppl you do it easy, greep process && kill. the end.